package com.example.carlok.admin

data class JobList(
    val imageJob : String? =null,
    var namaPekerjaan: String? = null,
    var tempatBekerja: String? = null,
    var waktuBekerja: String?= null,
    var deskripsiPekerjaan : String?=null,
    val email : String?=null,

)
